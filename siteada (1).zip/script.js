var nome, email, telefone, botaoEnviar

nome = document.getElementById("nome").value
email = document.getElementById("email").value
telefone = document.getElementById("telefone").value
botaoEnviar = document.getElementById("botaoEnviar")

botaoEnviar.addEventListener("click", verificarPreenchimento)

function verificarPreenchimento()
{
  //eu não sei pq tá dando errado, na teoria o código está correto, mas o operador && (E) não tá rolando (no console F12 rola)
  if(nome != "" && email != "" && telefone != "")
  {
    alert("Cadastrado com sucesso!")
  }
  else
  {
    alert("Preencha os dados corretamente")
  }
}