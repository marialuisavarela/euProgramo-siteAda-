var nome, email, botaoEnviar

nome = document.getElementById("nome")
email = document.getElementById("email")
botaoEnviar = document.getElementById("botaoEnviar")

botaoEnviar.addEventListener("clique",verificarCampos)

function verificarCampos()
{
  if(nome.value == "" || email == "")
  {
    alert("Preencha o formulário corretamente")
  }
  else
  {
    alert("ainda tem que programar essa parte")
  }
}
/*if(document.getElementById("nome").value != "" && document.getElementById("email").value != ""){
  alert("Prontinho! Você receberá as novidades por email.")
}else{
  alert("Por favor, preencha os campos nome e email!")
}*/